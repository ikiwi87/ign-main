<!doctype html>
<html lang="en">

<head>
    <!-- META -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="author" content="TienDat" />
    <meta name="robots" content="" />
    <meta name="description" content="IKMC @yield('description')" />

    <!-- FAVICONS ICON -->
    <link rel="icon" href="fe/img/favicon.ico" type="image/x-icon" />
    {{-- <link rel="shortcut icon" type="image/x-icon" href="fe/img/favicon.png" /> --}}

    <!-- PAGE TITLE HERE -->
    <title>IKMC 2021 @yield('title')</title>

    <base href="{{asset("")}}">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="fe/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="fe/bootstrap/css/bootstrap-grid.css">

    <!--Stylesheet-->
    <link rel="stylesheet" type="text/css" href="fe/css/normailze.css">
    <link rel="stylesheet" type="text/css" href="fe/css/style.css">
    <link rel="stylesheet" type="text/css" href="fe/css/responsive.css">

    <!--Font-->
    <link rel="stylesheet" type="text/css" href="fe/font/web-font.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/all.min.css" rel="stylesheet">

</head>

<body>
    <div class="main-container yoga-template">
        <!--Banner section-->
        <div class="banner">
            {{-- <div class="banner-overlay"></div> --}}
            <div class="inside-container top-bar">
                <div class="row">
                    <div class="col-md-4 top-bar-left order-2 order-md-12">
                        <i class="fas fa-envelope-open-text"></i>
                        <a href="mailto:ikmc@ieg.vn">ikmc@ieg.vn</a>
                    </div>
                    <div class="col-md-4 logo order-1 order-md-12">
                        <img class="logo-img" src="fe/img/logo.svg" alt="">
                    </div>
                    <div class="col-md-4 top-bar-right order-3 order-md-12">
                        <i class="fas fa-phone-alt"></i>
                        <a href="tel:0981048228">098 104 8228</a>
                    </div>
                </div>
            </div>
            <div class="inside-container banner-content">
                <div class="row">
                    {{-- <div class="col-12 content-col">
                        <h2 class="site-title">INTERNATIONAL KANGAROO MATH CONTEST - IKMC</h2>
                        <p class="site-title-desc">

                        </p>
                        <a class="banner-btn" href="/#register">Register now</a>
                    </div> --}}
                </div>
            </div>
        </div>
        <!--Contact us-->
        <div class="inside-container contact-section">
            @yield('content')
        </div>
        <div class="inside-container join-us-section">
            <div class="row sections-detail">
                <div class="col-12">
                    <h2 class="section-title">Liên hệ</h2>
                    <p class="section-title-desc">Mọi thắc mắc vui lòng liên hệ BTC</p>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <a href="tel:0981048228" class="join-us-btn">Call: 098 104 8228</a>
                    <p class="join-us-call">or Call : <a href="tel:093 625 5598"
                            class="join-us-phone-nr">093 625 5598</a></p>
                </div>
            </div>
        </div>

        <!--Copyright-->
        <footer class="footer">
            <div class="copyright">
                <div class="inside-container">
                    <div class="row">
                        <div class="col-md-6 order-2 order-md-12">
                            <p>&copy; 2020 All Rights Reserved. Created by <a href="https://ieg.vn/"
                                    class="created-by">IEG</a></p>
                        </div>
                        <div class="col-md-6 social order-1 order-md-12">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-google-plus-g"></i></a>
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->


    <script src="https://code.jquery.com/jquery-3.3.1.min.js"
        integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script src="http://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>

    <script src="fe/js/inputmask.js"></script>
    <script src="fe/js/inputmask.extensions.js"></script>
    <script src="fe/js/inputmask.date.extensions.js"></script>
    <script src="fe/js/jquery.inputmask.js"></script>
    <script>
        $.ajaxSetup({
  headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  }
});

    </script>

    <script>
        $(document).ready(function(){
        $("#date").inputmask("99/99/9999",{ "placeholder": "dd/mm/yyyy" });
        jQuery(window).on('scroll', function(){'use strict';
        if ( jQuery(window).scrollTop() > 300 ) {
        jQuery('#masthead').addClass('animated fadeInDown sticky');
        } else {
        jQuery('#masthead').removeClass('animated fadeInDown sticky');
        }
    });
    $(".navbar-nav li a, footer a[href='#homepage'], navbar-header a[href='#homepage']").click(function(event) {
        /* Act on the event */
        var target = $(this).attr('href');
        $('html, body').animate({
        scrollTop: $(target).offset().top
        }, 2000);
    });

    })
    $("#province").change(function(){
    if($(this).val() !== 0){
        $.ajax({
        url: 'http://'+window.location.host+'/getdistrict',
        type:'get',
        data:{
            'province_id':$(this).val()
        },
        success: function(data){
            var select = $("#district");
            select.empty();
            console.log(data.districts);
            if(data.state){
            var districts = data.districts;
                $("<option>").val(0).text('chọn quận/huyện').appendTo(select).attr("disabled", true).attr("hidden", true);
            $.each(districts, function(i, district){
                $("<option>").val(district.districtid).text(district.name).appendTo(select);
            });
            }
        }

        });
    }
    });
    $("#district").change(function(){
    if($(this).val() !== 0){
        $.ajax({
        url: 'http://'+window.location.host+'/getschool',
        type:'get',
        data:{
            'district_id':$(this).val()
        },
        success: function(data){
            var select = $("#school");
            select.empty();
            console.log(data.schools);
            if(data.state){
            var schools = data.schools;
                $("<option>").val(0).text('chọn trường').appendTo(select).attr("disabled", true).attr("hidden", true);
            $.each(schools, function(i, school){
                $("<option>").val(school.id).text(school.name).appendTo(select);
            });
            }
        }

        });
    }
    });
    </script>


    <script type="text/javascript">
        $(document).ready(function(){
        for(var i=0; i<document.forms.length; ++i){
            document.forms[i].reset();
        }

        $('input[name=combo]').change(function(){
        if(this.value == 0)
        {
        $('input[name=isset_account][value=0]').attr('disabled',true);
        $('input[name=isset_account][value=1]').attr('disabled',true);
            $("#club_account").slideUp();
            $("#have_account").slideUp();
            $("#isset_account").prop('required', false);
        }
        if(this.value == 1)
        {
        $('input[name=isset_account][value=0]').prop('checked',true);
        $('input[name=isset_account][value=0]').attr('disabled',false);
        $('input[name=isset_account][value=1]').attr('disabled',false);
            $("#have_account").slideDown();
            $("#isset_account").prop('required', true);
        }
        });

        $('input[name=isset_account]').change(function(){
            if(this.value == 1)
            {
            $("#club_account").slideDown();
            $("#address").prop('required', true);
            $(".club_account").prop('required', true);
            }
            if(this.value == 0)
            {
            $("#club_account").slideUp();
            $("#address").prop('required', false);
            }
        });
    
        });
    </script>

    <script src="fe/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>