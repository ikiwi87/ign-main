@extends('fe.layouts.index')

@section('title')
    
@endsection
@section('content')
<div class="row sections-detail">
    <div class="col-12">
        <h2 class="section-title" id="register">Đăng ký tham dự IKMC 2021</h2>
        <p class="section-title-desc">Hạn đăng ký: 15/12/2020 - 30/01/2021</p>
        <p class="section-title-desc"><b>Vui lòng làm đẩy đủ theo các bước bên dưới</b></p>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="appointment">
            <h2 class="appointment-title">Thông tin đăng ký</h2>
            <form method="post">
                {{ csrf_field() }}
                <div class="row">
                    <h4 class="appointment-title" style="font-size: 1.5rem">Bước 1:</h4>
                    
                    <div class="form-group col-sm-12 col-xs-12">@if(session('msg'))
                        <div class="alert alert-danger row">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            {{ session('msg') }}
                        </div>
                        @endif
                        @if(session('check'))
                        <div class="alert alert-success row">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            {{ session('check') }}
                        </div>
                        @endif
                        <label class="control-label">Email</label>
                        <div class="row">
                            <div class="col-sm-6">
                                <input type="email" class="form-control" name="email" required="true"
                                    placeholder="VD: kangaroo@ieg.vn" value="{{ session('email') }}">
                            </div>
                            <div class="col-sm-3">
                                <input type="submit" class="btn btn-primary form-control"
                                    {{-- onclick="return confirm('Are you sure you want to submit the evalution?')" --}}
                                    formaction="{{route('verify_email')}}" value="Gửi mã xác nhận">
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection