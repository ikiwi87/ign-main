
@extends('fe.layouts.index')

@section('title')
    
@endsection
@section('content')

<div class="row sections-detail">
    <div class="col-12">
        <h2 class="section-title" id="register">ĐĂNG KÝ THÀNH CÔNG!</h2>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="appointment" style="background-color: #fff; 
        color: #000;">
            <h2 class="appointment-title">Thông tin thanh toán</h2>
            <div class="row">
                <div class="col-md-12">
                    <div class="title-wrapper">
                        <div class="title-h2">
                            <h2>Quý phụ huynh vui lòng hoàn thành thanh toán theo hướng dẫn bên
                                dưới.</h2>
                            <p style="color: #ff0000; font-style: oblique;">
                                <strong>Lưu ý:</strong> Lệ phí sẽ không được hoàn lại dưới mọi hình
                                thức.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div style="text-align: left;">
                <br>
                <h3><strong>Cách 1: Chuyển khoản cho BTC theo thông tin:</strong></h3>
                <p>
                    <strong>Ngân hàng: </strong> TMCP Kỹ thương Việt Nam (Techcombank) - Chi nhánh Ba Đình
                </p>
                <p>
                    <strong>Chủ tài khoản:</strong> Công ty TNHH Quỹ Phát triển Giáo dục IEG
                </p>
                <p>
                    <strong>Số tài khoản:</strong> 19134671571018
                </p>
                <p>
                    <strong>Số tiền:</strong> @if ($student->combo == 0)
                    350.000 vnđ
                    @else
                    600.000 vnđ
                    @endif
                </p>
                <p>
                    <strong>Nội dung chuyển khoản:</strong>
                    <span class="red-text">
                        IKMC{{str_pad($student->id, 5, '0', STR_PAD_LEFT)}}-{{$student->parent_phone}}-{{$student->slug_name}}</span>
                </p>
                <b>Hoặc</b>
                <p>
                    <strong>Ngân hàng: </strong> TMCP Ngoại thương Việt Nam (Vietcombank)- Hà Nội
                </p>
                <p>
                    <strong>Chủ tài khoản:</strong> CT TNHH QUY PHAT TRIEN GIAO DUC IEG
                </p>
                <p>
                    <strong>Số tài khoản:</strong> 0021000401539
                </p>
                <p>
                    <strong>Số tiền:</strong> @if ($student->combo == 0)
                    350.000 vnđ
                    @else
                    600.000 vnđ
                    @endif
                </p>
                <p>
                    <strong>Nội dung chuyển khoản:</strong>
                    <span class="red-text">
                        IKMC{{str_pad($student->id, 5, '0', STR_PAD_LEFT)}}-{{$student->parent_phone}}-{{$student->slug_name}}</span>
                </p>
            </div>
            <div style="text-align: left; margin-right: 50px;">
                <br>
                <h3><strong>Cách 2: Nộp trực tiếp</strong></h3>
                <strong>Địa chỉ:</strong> Quỹ phát triển Giáo dục IEG,
                128 Nguyễn Thái Học, Ba Đình, Hà Nội<br>
            </div>
        </div>
    </div>
    
</div>
<div class="inside-container join-us-section">
    <div class="row">
        <div class="col-12">
            <a href="/" class="join-us-btn">Về trang chủ</a>
        </div>
    </div>
</div>
@endsection