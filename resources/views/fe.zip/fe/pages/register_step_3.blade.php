@extends('fe.layouts.index')

@section('title')

@endsection
@section('content')
<div class="row sections-detail">
    <div class="col-12">
        <h2 class="section-title" id="register">Đăng ký tham dự IKMC 2021</h2>
        <p class="section-title-desc">Hạn đăng ký: 15/12/2020 - 30/01/2021</p>
        <p class="section-title-desc"><b>Vui lòng làm đẩy đủ theo các bước bên dưới</b></p>
    </div>
</div>
@if ($student->done == 1)
    
<div class="row">
    <div class="col-lg-12">
        <div class="appointment">
            <h2 class="appointment-title">Email đã được đăng ký thành công!</h2>
        </div>
    </div>
</div>
@else
<div class="row">
    <div class="col-lg-12">
        <div class="appointment">
            <h2 class="appointment-title">Thông tin đăng ký</h2>
            <form method="post" action="{{route('store_student')}}" class="text-left" accept-charset="utf-8"
                id="registerform">
                {{ csrf_field() }}
                <div class="row">
                    <h4 class="appointment-title" style="font-size: 1.5rem">Bước 3</h4>
                    <div class="form-group col-sm-12 col-xs-12">
                        <div class="row">
                            <div class="col-sm-6">
                                <label class="control-label">Email</label>
                                <input type="email" class="form-control" disabled required="true"
                                    placeholder="VD: kangaroo@ieg.vn" value="{{ session('email') }}">
                            </div>
                            {{-- <div class="col-sm-6">
                                <label class="control-label">Email</label>
                                <input type="text" class="form-control" disabled required="true"
                                    placeholder="VD: kangaroo@ieg.vn" value="{{ session('verify_code') }}">
                        </div> --}}
                        <div class="row" hidden>
                            <div class="col-sm-6">
                                <label class="control-label">Email</label>
                                <input type="email" class="form-control" required="true" name="email"
                                    placeholder="VD: kangaroo@ieg.vn" value="{{ session('email') }}">
                            </div>
                            <div class="col-sm-6">
                                <label class="control-label">Email</label>
                                <input type="text" class="form-control" required="true" name="verify_code"
                                    placeholder="VD: kangaroo@ieg.vn" value="{{ session('verify_code') }}">
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        <div class="row">
            <label for="combo" class="col-sm-6 col-md-offset-2 col-form-label">Gói đăng ký:
                <p style="color: #ff0000; font-style: oblique;">*Cả 2 gói đều bao gồm sách và áo.
                </p>
            </label>
            <div class="col-sm-6">
                <div class="radio">
                    <label><input type="radio" name="combo" value="0" required> Thi</label>
                </div>
                <div class="radio">
                    <label><input type="radio" name="combo" value="1" required> Combo: thi + 12
                        tháng Câu lạc bộ KMC</label>
                </div>
            </div>

            <label class="control-label">

            </label>
        </div>
        <hr>
        <div class="row" id="have_account" hidden>
            <div class="form-group col-sm-6 col-xs-12">
                <label for="isset_account">Bạn đã có tài khoản tại <a target="_blank"
                        href="https://kangaroo-math.vn/club">kangaroo-math.vn</a>? </label>
            </div>
            <div class="col-sm-6">
                <div class="radio">
                    <label><input type="radio" name="isset_account" value="0" required> Chưa có tài
                        khoản Câu lạc bộ</label>
                </div>
                <div class="radio">
                    <label><input type="radio" name="isset_account" value="1" required> Đã có tài
                        khoản Câu lạc bộ</label>
                </div>
            </div>
        </div>
        <div class="row" id="club_account" hidden>
            <div class="form-group col-sm-10 col-xs-12">
                <label for="address" class="control-label">Nhập tài khoản Câu lạc bộ của
                    bạn:</label>
                <label class="control-label">
                    <p style="color: #ff0000; font-style: oblique;">*Vui lòng điền đúng tài khoản để
                        việc nâng cấp tài
                        khoản được nhanh chóng.</p>
                </label>

                <input type="text" class="form-control" name="club_account" placeholder="VD: Nguyễn Văn, Nguyễn Duy ..">
            </div>
        </div>
        <hr>

        <h2 class="appointment-title">Thông tin học sinh</h2>
        <div class="row">
            <div class="form-group col-sm-6 col-xs-12">
                <label class="control-label">Họ tên đệm học sinh</label>
                <input type="text" class="form-control" name="last_name" required="true" placeholder="VD: Nguyễn Thị">
            </div>
            <div class="form-group col-sm-6 col-xs-12">
                <label class="control-label">Tên học sinh</label>
                <input type="text" class="form-control" name="first_name" required="true" placeholder="VD: Trâm">
            </div>
        </div>
        <div class="row">
            <div class="col-sm-2 form-group">
                <label class="control-label">Ngày sinh</label>
                <select name="day" class="form-control">
                    <option value="none" selected="" hidden disabled="">
                        Ngày sinh</option>
                    <option value="01">01</option>
                    <option value="02">02</option>
                    <option value="03">03</option>
                    <option value="04">04</option>
                    <option value="05">05</option>
                    <option value="06">06</option>
                    <option value="07">07</option>
                    <option value="08">08</option>
                    <option value="09">09</option>
                    <option value="10">10</option>
                    <option value="11">11</option>
                    <option value="12">12</option>
                    <option value="13">13</option>
                    <option value="14">14</option>
                    <option value="15">15</option>
                    <option value="16">16</option>
                    <option value="17">17</option>
                    <option value="18">18</option>
                    <option value="19">19</option>
                    <option value="20">20</option>
                    <option value="21">21</option>
                    <option value="22">22</option>
                    <option value="23">23</option>
                    <option value="24">24</option>
                    <option value="25">25</option>
                    <option value="26">26</option>
                    <option value="27">27</option>
                    <option value="28">28</option>
                    <option value="29">29</option>
                    <option value="30">30</option>
                    <option value="31">31</option>
                </select>
            </div>
            <div class="col-sm-2 form-group">
                <label class="control-label">Tháng sinh</label>
                <select name="month" class="form-control">
                    <option value="none" selected="" hidden disabled="">
                        Tháng sinh</option>
                    <option value="01">01</option>
                    <option value="02">02</option>
                    <option value="03">03</option>
                    <option value="04">04</option>
                    <option value="05">05</option>
                    <option value="06">06</option>
                    <option value="07">07</option>
                    <option value="08">08</option>
                    <option value="09">09</option>
                    <option value="10">10</option>
                    <option value="11">11</option>
                    <option value="12">12</option>
                </select>
            </div>
            <div class="col-sm-2 form-group">
                <label class="control-label">Năm sinh</label>
                <select name="year" class="form-control">
                    <option value="none" selected="" hidden disabled="">
                        Năm sinh</option>
                    <option value="2007">2007</option>
                    <option value="2008">2008</option>
                    <option value="2009">2009</option>
                    <option value="2010">2010</option>
                    <option value="2011">2011</option>
                    <option value="2012">2012</option>
                    <option value="2013">2013</option>
                    <option value="2014">2014</option>
                </select>
            </div>
            <div class="col-sm-6 form-group">
                <label class="control-label">Giới tính</label>
                <select class="form-control" name="gender">
                    <option style="color:#122111;" value="" selected="" hidden disabled="">Giới tính
                    </option>
                    <option value="Nam">Nam</option>
                    <option value="Nữ">Nữ</option>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-6">
                <label class="control-label">Khối lớp</label>
                <select name="grade" class="form-control">
                    <option value="none" selected="" hidden disabled="">
                        Chọn khối lớp</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                </select>
            </div>
            <div class="form-group col-md-6">
                <label class="control-label">Lớp</label>
                <input type="text" class="form-control" name="class" required="true">
            </div>
        </div>
        <h3 style="margin-left: 12px">Thông tin trường</h3>
        <div class="row">
            <div class="form-group col-sm-6">
                <label class="control-label">Tỉnh/thành - ĐC Trường</label>
                <select class="form-control" name="school_province" id="province">
                    <option selected="" hidden disabled="">-Tỉnh thành-</option>
                    @foreach($provinces as $province)
                    <option value="{{$province->provinceid}}">{{ $province->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group col-sm-6">
                <label class="control-label">Quận/huyện - ĐC Trường</label>
                <select name="school_district" class="form-control" id="district">
                    <option value="" selected="" hidden disabled="">-Quận Huyện-</option>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-sm-6">
                <label class="control-label">Trường</label>
                <select name="school_id" class="form-control" id="school" required>
                    <option value="" selected="" hidden disabled="">-Trường-</option>
                </select>
            </div>
        </div>
        <hr>
        <h2 class="appointment-title">Thông tin phụ huynh</h2>
        <div class="row">
            <div class="form-group col-sm-6">
                <label class="control-label">Họ tên phụ huynh</label>
                <input type="text" class="form-control" name="parent_name" required="true">
            </div>
            <div class="form-group col-sm-6">
                <label class="control-label" hidden>Email</label>
                <input type="text" class="form-control" name="email" hidden value="{{session('email')}}">
            </div>
        </div>
        <div class="row">
            <div class="form-group col-sm-6">
                <label class="control-label">SĐT</label>
                <input type="text" class="form-control" maxlength="10" value="0" name="parent_phone">
            </div>
            <div class="form-group col-sm-6">
                <label class="control-label">Địa chỉ</label>
                <input type="text" class="form-control" name="parent_address" required="true">
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-12 text-right">
                <button type="submit" class="btn btn-primary" id="btnRegister">ĐĂNG KÝ!</button>
            </div>
        </div>
        </form>
    </div>
</div>
@endif

@endsection